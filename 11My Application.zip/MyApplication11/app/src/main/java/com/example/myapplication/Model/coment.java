package com.example.myapplication.Model;

public class coment {
    private String id,id_pr,user_email,decreption,data,rating;

    public String getId ( ) {
        return id;
    }

    public void setId ( String id ) {
        this.id = id;
    }

    public String getId_pr ( ) {
        return id_pr;
    }

    public void setId_pr ( String id_pr ) {
        this.id_pr = id_pr;
    }

    public String getUser_email ( ) {
        return user_email;
    }

    public void setUser_email ( String user_email ) {
        this.user_email = user_email;
    }

    public String getDecreption ( ) {
        return decreption;
    }

    public void setDecreption ( String decreption ) {
        this.decreption = decreption;
    }

    public String getData ( ) {
        return data;
    }

    public void setData ( String data ) {
        this.data = data;
    }


    public String getRating ( ) {
        return rating;
    }

    public void setRating ( String rating ) {
        this.rating = rating;
    }

    public coment ( ) {
    }
}
