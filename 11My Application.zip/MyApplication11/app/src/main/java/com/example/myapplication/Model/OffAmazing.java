package com.example.myapplication.Model;

public class OffAmazing {
    private String  id,name,img_link,id_list,value_off,price,offprice;

    public String getId ( ) {
        return id;
    }

    public void setId ( String id ) {
        this.id = id;
    }

    public String getName ( ) {
        return name;
    }

    public void setName ( String name ) {
        this.name = name;
    }

    public String getImg_link ( ) {
        return img_link;
    }

    public void setImg_link ( String img_link ) {
        this.img_link = img_link;
    }

    public String getId_list ( ) {
        return id_list;
    }

    public void setId_list ( String id_list ) {
        this.id_list = id_list;
    }

    public String getValue_off ( ) {
        return value_off;
    }

    public void setValue_off ( String value_off ) {
        this.value_off = value_off;
    }

    public String getPrice ( ) {
        return price;
    }

    public void setPrice ( String price ) {
        this.price = price;
    }

    public String getOffprice ( ) {
        return offprice;
    }

    public void setOffprice ( String offprice ) {
        this.offprice = offprice;
    }

    public OffAmazing ( ) {
    }
}
