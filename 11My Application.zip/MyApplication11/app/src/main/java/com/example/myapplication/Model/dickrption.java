package com.example.myapplication.Model;

public class dickrption {
    private String id , description ,id_pr;

    public String getId ( ) {
        return id;
    }

    public void setId ( String id ) {
        this.id = id;
    }

    public String getDescription ( ) {
        return description;
    }

    public void setDescription ( String description ) {
        this.description = description;
    }

    public String getId_pr ( ) {
        return id_pr;
    }

    public void setId_pr ( String id_pr ) {
        this.id_pr = id_pr;
    }

    public dickrption ( ) {
    }
}
