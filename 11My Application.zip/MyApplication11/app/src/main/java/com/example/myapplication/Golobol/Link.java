package com.example.myapplication.Golobol;

public class Link {


    public static final String SLIDER_BANER = "http://192.168.1.5/viewpajer/getslider.php";
    public static final String LIST_HOEM = "http://192.168.1.5/viewpajer/getlistHome.php";
    public static final String AMAZING_OFFER = "http://192.168.1.5/viewpajer/getamaingoffer.php";
    public static final String ALL_KALA = "http://192.168.1.5/viewpajer/getAllkala.php" ;
    public static final String BRAND = "http://192.168.1.5/viewpajer/getbrand.php";
    public static final String LIST_CATEGORY = "http://192.168.1.5/viewpajer/Category.php";
    public static final String DITEL_CATEGORY = "http://192.168.1.5/viewpajer/Ditelcategori.php";
    public static final String IMG_DITEL_CATEGORY ="http://192.168.1.5/viewpajer/getimg_pr.php";
    public static final String SIMILAR_DITEL_CATEGORY = "http://192.168.1.5/viewpajer/getsimilar.php";
    public static final String COMENT_DITEL_CATEGORY = "http://192.168.1.5/viewpajer/getComent.php";
    public static final String BRAND_DITEL = "http://192.168.1.5/viewpajer/getDitelBrand.php";
    public static final String QUESTION = "http://192.168.1.5/viewpajer/getQuestion.php";
    public static final String ALL_KALA_DITEL = "http://192.168.1.5/viewpajer/getAllkala_ditel.php";
    public static final String SEARCH = "http://192.168.1.5/viewpajer/getSearch.php" ;
    public static final String description_DITEL_CATEGORY = "http://192.168.1.5/viewpajer/gettechnical.php";

    public static final String GERON = "http://192.168.1.5/viewpajer/getPR_ASC.php";
    public static final String ARZON = "http://192.168.1.5/viewpajer/getPR_DESC.php";
    public static final String VIEW = "http://192.168.1.5/viewpajer/getPR_ASC_view.php";
}
