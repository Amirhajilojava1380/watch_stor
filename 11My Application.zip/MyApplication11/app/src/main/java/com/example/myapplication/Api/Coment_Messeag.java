package com.example.myapplication.Api;

public class Coment_Messeag {
    private  String massage;
    private  boolean status;

    public Coment_Messeag ( ) {
    }

    public String getMassage ( ) {
        return massage;
    }

    public void setMassage ( String massage ) {
        this.massage = massage;
    }

    public boolean isStatus ( ) {
        return status;
    }

    public void setStatus ( boolean status ) {
        this.status = status;
    }
}
