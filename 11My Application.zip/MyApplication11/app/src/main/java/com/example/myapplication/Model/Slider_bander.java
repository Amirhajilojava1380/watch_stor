package com.example.myapplication.Model;

public class Slider_bander {
    private String id ,img_link;

    public String getId ( ) {
        return id;
    }

    public void setId ( String id ) {
        this.id = id;
    }

    public String getImg_link ( ) {
        return img_link;
    }

    public void setImg_link ( String img_link ) {
        this.img_link = img_link;
    }

    public Slider_bander ( ) {
    }
}
