package com.example.myapplication.Golobol;

public class Key {

    public static String id = "id";

    public static String name="name";

    public static String Img_link = "Img_link";

    public static String Price="Price";

    public static String Id_list="Id_list";
}
